import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Form1 extends JFrame {
    private JPanel panelMain;
    private JTextArea coJeSmartHomeTextArea;
    private JButton chciMítSmartHomeButton;
    private JButton užSiDělámSmartButton;
    Form1 thisForm = this; // this by se v tlačítkách vztahovalo k listeneru

    public Form1()
    {
        setContentPane(panelMain);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        pack();
        chciMítSmartHomeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
                Form2 f2 = new Form2();
                f2.setVisible(true);
            }
        });
        užSiDělámSmartButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFileChooser fc = new JFileChooser();
                int result = fc.showOpenDialog(thisForm);
                if(result==JFileChooser.APPROVE_OPTION) {
                    Form3 f3 = new Form3(fc.getSelectedFile().getPath());
                    f3.setVisible(true);
                    setVisible(false);
                }
                else { JOptionPane.showMessageDialog(thisForm, "Soubor nevybrán.", "Poznámka", JOptionPane.INFORMATION_MESSAGE); }
            }
        });
    }

    public static void main(String[] args) {
        Form1 f1 = new Form1();
        f1.setVisible(true);
        //test
    }
}
