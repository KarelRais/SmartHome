import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.nio.file.*;

import static java.nio.file.Files.*;

public class Form21 extends JFrame {
    private JTextArea textArea1;
    private JPanel panelMain;
    private JButton anoVšeKupujiButton;
    private JButton neButton;
    Form21 thisForm = this; // this by se v tlačítkách vztahovalo k listeneru

    public void deleteDirectory(File path)
    {
        for(File file : path.listFiles()) {
            if(file.isDirectory()) { deleteDirectory(file); }
            file.delete();
        }
    }

    public Form21(int lights, int switches, int motion, int alarms, int lsens, int air, String path)
    {
        setContentPane(panelMain);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        int lights1, switches1, motion1, alarms1, lsens1, air1;
        lights1 = Math.max(lights, 0); // pro korekci záporných čísel
        switches1 = Math.max(switches, 0);
        motion1 = Math.max(motion, 0);
        alarms1 = Math.max(alarms, 0);
        lsens1 = Math.max(lsens, 0);
        air1 = Math.max(air, 0);

        int com_buttons = 4*switches1;

        textArea1.append("Mikrokontrolérů: " + String.valueOf(1));
        textArea1.append("\nTlačítek: " + String.valueOf(com_buttons));
        textArea1.append("\nRGB žárovek: " + String.valueOf(lights1));
        textArea1.append("\nPohybových čidel: " + String.valueOf(motion1));
        textArea1.append("\nAkustických alarmů: " + String.valueOf(alarms1));
        textArea1.append("\nFotodiod: " + String.valueOf(lsens1));
        textArea1.append("\nSenzorů CO2: " + String.valueOf(air1));
        textArea1.append("\nSenzorů teploty a vlhkosti: " + String.valueOf(air1));
        textArea1.append("\nPlus displej, kabeláž, hlavní vypínač, mobil a počítač.");
        textArea1.append("\n\nPromyslete si, zda opravdu na to máte!");

        pack();

        anoVšeKupujiButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                thisForm.setVisible(false);
                Form3 f3 = new Form3(path);
                f3.setVisible(true);
            }
        });
        neButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try { deleteDirectory(new File(path)); }
                catch(Exception e1) { JOptionPane.showMessageDialog(thisForm, "CHYBA: Nemožnost smazat soubor.", "Chyba", JOptionPane.ERROR_MESSAGE); }
                thisForm.setVisible(false);
            }
        });
    }
}
