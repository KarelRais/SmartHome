import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Form6 extends JFrame {
    private JPanel panel1;
    private JTextArea doporučujemeCelouChytrouDomácnostTextArea;
    private JButton oslavmeToButton;

    public Form6()
    {
        setContentPane(panel1);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        oslavmeToButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Form7 f7 = new Form7();
                f7.setVisible(true);
                setVisible(false);
            }
        });
    }
}