import javax.swing.*;

public class Form7 extends JFrame {
    private JPanel panel1;
    private JTextArea OSLAVTETOVězteŽeTextArea;
    public Form7()
    {
        setContentPane(panel1);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
