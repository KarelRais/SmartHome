import javax.swing.*;
import javax.swing.event.TableModelListener;
import javax.swing.table.TableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.PrintWriter;

class data1 {
    static String[][] code = new String[20][2];
    public static String[][] getCode() { return code; }
    public static void setCode(int x, int y, String value) { code[x][y] = value; }
}

class MyTableModel1 implements TableModel {

    @Override
    public int getRowCount() {
        return 20;
    }

    @Override
    public int getColumnCount() {
        return 2;
    }

    @Override
    public String getColumnName(int columnIndex) {
        switch(columnIndex)
        {
            case 0:
                return "Název";
            case 1:
                return "Příkaz(y)";
            default:
                return null;
        }
    }

    @Override
    public Class<?> getColumnClass(int columnIndex) {
        return String.class;
    }

    @Override
    public boolean isCellEditable(int rowIndex, int columnIndex) {
        return true;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        return data1.getCode()[rowIndex][columnIndex];
    }

    @Override
    public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
        data.setCode(rowIndex, columnIndex, (String)aValue);
    }

    @Override
    public void addTableModelListener(TableModelListener l) {

    }

    @Override
    public void removeTableModelListener(TableModelListener l) {

    }
}

public class Form4 extends JFrame {
    private JTable table1;
    private JPanel panel1;
    private JButton uložitAPokračovatButton;
    private JTextField textField1;

    public Form4(String path) {
        setContentPane(panel1);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        Form4 thisForm = this; // this by se v tlačítkách vztahovalo k listeneru
        textField1.setText("Pozn.: Více příkazů (z předchozího kroku) oddělujte mezerou.");
        uložitAPokračovatButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                for(String[] str : data.getCode())
                {
                    String name = str[0];
                    String[] commands = str[1].split(" ");
                    try(PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter(path + "\\" + name + ".ps1"))))
                    {
                        pw.println("$port = new-Object System.IO.Ports.SerialPort COM2,9600,None,8,one");
                        pw.println("$port.open()");
                        for(String str1 : commands) { pw.println("$port.WriteLine(\""+str1+"\")"); }
                        pw.println("$port.close()");
                        pw.flush();

                        /*/Form5 f5 = new Form5();
                        f5.setVisible(true);*/
                        setVisible(false);
                    }
                    catch(Exception e1)
                    {
                        JOptionPane.showMessageDialog(thisForm, "CHYBA: Nemožnost vytvořit soubor. Zkontrolujte oprávnění.", "Chyba", JOptionPane.ERROR_MESSAGE);
                    }
                }
            }
        });
    }

    private void createUIComponents() {
        // TODO: place custom component creation code here
        table1 = new JTable(new MyTableModel1());
    }
}