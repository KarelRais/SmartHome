import javax.swing.*;
import javax.swing.event.TableModelListener;
import javax.swing.table.TableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.PrintWriter;

class data
{
    static String[][] code = new String[20][2];
    public static String[][] getCode() { return code; }
    public static void setCode(int x, int y, String value) { code[x][y] = value; }
}

class CO2
{
    static double calcRs(int sensorReading)
    {
        return (1024/(sensorReading/11.0)-1)*10;
    }

    static double calcfRHT(double RH, double T)
    {
        return 1.782663144+(-0.748177946)*RH+(-0.015924756)*T+0.006677957*T;
    }

    static double calcCO2(double Rs, double fRHT)
    {
        return 410*Math.pow((Rs/fRHT)/250.0, -2.769034857);
    }

    public static double calculate(int sensor, double temp, double hum)
    {
        return calcCO2(calcRs(sensor), calcfRHT(temp, hum));
    }
}

class MyTableModel implements TableModel {

    @Override
    public int getRowCount() {
        return 40;
    }

    @Override
    public int getColumnCount() {
        return 2;
    }

    @Override
    public String getColumnName(int columnIndex) {
        switch(columnIndex)
        {
            case 0:
                return "Vstup";
            case 1:
                return "Akce";
            default:
                return null;
        }
    }

    @Override
    public Class<?> getColumnClass(int columnIndex) {
        return String.class;
    }

    @Override
    public boolean isCellEditable(int rowIndex, int columnIndex) {
        return true;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        try { return data.getCode()[rowIndex][columnIndex]; }
        catch(Exception e1) { return null; }
    }

    @Override
    public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
        data.setCode(rowIndex, columnIndex, (String)aValue);
    }

    @Override
    public void addTableModelListener(TableModelListener l) {

    }

    @Override
    public void removeTableModelListener(TableModelListener l) {

    }
}

public class Form3 extends JFrame {
    private JPanel panel1;
    private JTable table1;
    private JTextPane VSTUPYNástěnnýOvladačOvladacTextPane;
    private JButton uložitAPokračovatButton;
    private JScrollBar scrollBar1;
    Form3 thisForm = this; // this by se v tlačítkách vztahovalo k listeneru

    public Form3(String path)
    {
        setContentPane(panel1);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1000, 1000);

        try(PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter(path + "\\code.ino"))))
        {
            pw.println("#include <LiquidCrystal_I2C.h>");
            pw.println("#include <Serial.h>");
            pw.println("#include <dht.h>");
            pw.println("LiquidCrystal_I2C lcd(0x27, 20, 4);");
            pw.println("dht dht1;");
            pw.println("void setup() {");
            pw.println("lcd.init();");
            pw.println("lcd.backlight();");
            pw.println("Serial.begin(9600);");
            pw.println("for(int i=2; i<=24; i++) { pinMode(i, INPUT); }");
            pw.println("for(int j=25; i<=48; j++) { pinMode(j, OUTPUT); }");
            pw.println("}");

            pw.println("double calcRs(int sensorReading) { return (1024/(sensorReading/11.0)-1)*10; }");
            pw.println("double calcfRHT(double RH, double T) { return 1.782663144+(-0.748177946)*RH+(-0.015924756)*T+0.006677957*T; }");
            pw.println("double calcCO2(double Rs, double fRHT) { return 410*Math.pow((Rs/fRHT)/250.0, -2.769034857); }");

            pw.println("void loop() {");
            pw.flush();
        }
        catch (Exception e1)
        {
            JOptionPane.showMessageDialog(this, "CHYBA: Nemožnost vytvořit soubor. Zkontrolujte oprávnění.", "Chyba", JOptionPane.ERROR_MESSAGE);
        }

        uložitAPokračovatButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                WriteCode(path);
                Form4 f4 = new Form4(path);
                f4.setVisible(true);
                setVisible(false);
            }
        });
    }

    public void WriteCode(String path)
    {
        try(PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter(path + "\\code.ino"))))
        {
            for (String[] str : data.getCode()) {
                String[] input = str[0].split(":");
                String[] action = str[1].split(":");
                switch (input[0]) {
                    case "ovladac":
                        switch (input[2]) {
                            case "1":
                                pw.println("if(analogRead(" + input[1] + ")>0 && analogRead(" + input[1] + ")<=10) {");
                                break;
                            case "2":
                                pw.println("if(analogRead(" + input[1] + ")>10 && analogRead(" + input[1] + ")<=50 {");
                                break;
                            case "3":
                                pw.println("if(analogRead(" + input[1] + ")>50 && analogRead(" + input[1] + ")<=128 {");
                                break;
                            case "4":
                                pw.println("if(analogRead(" + input[1] + ")>128 {");
                                break;
                            default:
                                JOptionPane.showMessageDialog(this, "Špatné číslo ovladače.", "Chyba v kódu", JOptionPane.INFORMATION_MESSAGE);
                                break;
                        }
                    case "pc":
                        pw.println("if(Serial.read()==" + input[1] + ") {");
                        break;
                    case "pohyb":
                        int port1 = Integer.parseInt(input[1]) + 6;
                        pw.println("if(digitalRead(" + port1 + ")==HIGH) {");
                        break;
                    case "horko":
                        int port2 = Integer.parseInt(input[1]) + 12;
                        pw.println("int chk = dht1.read11(" + port2 + ");");
                        pw.println("if(dht1.temperature>" + input[2] + ") {");
                        break;
                    case "zima":
                        int port3 = Integer.parseInt(input[1]) + 12;
                        pw.println("int chk = dht1.read11(" + port3 + ");");
                        pw.println("if(dht1.temperature<" + input[2] + ") {");
                        break;
                    case "vlhko":
                        int port4 = Integer.parseInt(input[1]) + 12;
                        pw.println("int chk = dht1.read11(" + port4 + ");");
                        pw.println("if(dht1.humidity>" + input[2] + ") {");
                        break;
                    case "sucho":
                        int port5 = Integer.parseInt(input[1]) + 12;
                        pw.println("int chk = dht1.read11(" + port5 + ");");
                        pw.println("if(dht1.humidity<" + input[2] + ") {");
                        break;
                    case "oxid":
                        int portDHT = Integer.parseInt(input[1]) + 12;
                        int portCO2 = Integer.parseInt(input[1]) + 18;
                        pw.println("int chk = dht1.read11(" + portDHT + ");");
                        pw.println("double co2 = calcCO2(calcRs(analogRead(" + portCO2 + ")), calcfRHT(dht1.humidity, dht1.temperature));");
                        pw.println("if(co2>" + input[2] + ") {");
                        break;
                }
                switch(action[0]) {
                    case "displej":
                        pw.println("lcd.println(\""+action[1]+"\"); }");
                        break;
                    case "pc":
                        pw.println("Serial.print(\""+action[1]+"\"); }");
                        break;
                    case "svetlo":
                        int R = Integer.parseInt(input[1]) + 24;
                        int G = Integer.parseInt(input[1]) + 30;
                        int B = Integer.parseInt(input[1]) + 36;
                        pw.println("analogWrite("+R+", "+input[2]+");");
                        pw.println("analogWrite("+G+", "+input[3]+");");
                        pw.println("analogWrite("+B+", "+input[4]+"); }");
                        break;
                    case "sAlarm":
                        int port1 = Integer.parseInt(input[1]) + 24;
                        pw.println("for(int i=0; i<100; i++) {");
                        pw.println("analogWrite("+port1+", 255);");
                        pw.println("delay(1000);");
                        pw.println("analogWrite("+port1+", 0;");
                        pw.println("delay(1000); } }");
                        break;
                    case "zAlarm":
                        int port2 = Integer.parseInt(input[2]) + 42;
                        if(input[1]=="start") { pw.println("digitalWrite("+port2+", HIGH); }"); }
                        if(input[1]=="stop") { pw.println("digitalWrite("+port2+", LOW); }"); }
                        break;
                }
                pw.println("}");
                pw.flush();
            }
        }
        catch (Exception e1)
        {
            JOptionPane.showMessageDialog(this, "CHYBA: Nemožnost vytvořit soubor. Zkontrolujte oprávnění.", "Chyba", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void createUIComponents() {
        // TODO: place custom component creation code here
        table1 = new JTable(new MyTableModel());
    }
}
