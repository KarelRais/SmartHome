import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.nio.file.*;

import static java.nio.file.Files.*;

public class Form2 extends JFrame {
    private JPanel panelMain;
    private JTextField textField1;
    private JSpinner spinner1;
    private JSpinner spinner2;
    private JSpinner spinner3;
    private JSpinner spinner4;
    private JSpinner spinner5;
    private JSpinner spinner6;
    private JButton spočítatButton;
    Form2 thisForm = this; // this by v ActionListenerech odkazovalo na listener

    public Form2()
    {
        setContentPane(panelMain);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        pack();

        spočítatButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try
                {
                    createDirectory(Path.of(textField1.getText()));
                    try(PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter(textField1.getText()+"\\Description.iot"))))
                    {
                        pw.print((Integer)spinner1.getValue());
                        pw.print((Integer)spinner2.getValue());
                        pw.print((Integer)spinner3.getValue());
                        pw.print((Integer)spinner4.getValue());
                        pw.print((Integer)spinner5.getValue());
                        pw.print((Integer)spinner6.getValue());
                        pw.flush();
                        setVisible(false);
                        Form21 f21 = new Form21((Integer)spinner1.getValue(), (Integer)spinner2.getValue(), (Integer)spinner3.getValue(), (Integer)spinner4.getValue(), (Integer)spinner5.getValue(), (Integer)spinner6.getValue(), textField1.getText());
                        f21.setVisible(true);
                    }
                    catch(Exception e1)
                    {
                        JOptionPane.showMessageDialog(thisForm, "CHYBA: Není možné vytvořit soubor.", "Chyba", JOptionPane.ERROR_MESSAGE);
                    }
                }
                catch(Exception e1)
                {
                    JOptionPane.showMessageDialog(thisForm, "CHYBA: Není možné vytvořit složku.", "Chyba", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
    }
}
