import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Form5 extends JFrame {
    private JPanel panel1;
    private JTextArea konečněMůžeteVšeFyzickyTextArea;
    private JButton mámZapojenoButton;

    public Form5()
    {
        setContentPane(panel1);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        mámZapojenoButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Form6 f6 = new Form6();
                f6.setVisible(true);
                setVisible(false);
            }
        });
    }
}
