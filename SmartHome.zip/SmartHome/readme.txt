Pro použití a zprovoznění aplikace:
1. Nejprve si přečtěte dokument license.txt.
2. Pomocí JDK (např. IntelliJ IDEA) spusťte projekt.
3. Zvolte, zda začínáte nebo už máte rozděláno.
4. Zvolte množství zařízení pro chytrou domácnost, postupujte podle instrukcí programu.